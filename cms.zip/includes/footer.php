
<footer>
    <div class="footer-top">
        <div class="container">
            <div class="foo-grids">
                <div class="col-md-3 footer-grid">
                    <h4 class="footer-head">Who We Are</h4>
                    <p> adsnagar.com is FREE online classified which enables individuals as well as companies to list wide variety of new or used product online.</p>

                </div>
                <div class="col-md-3 footer-grid">
                    <h4 class="footer-head">Help</h4>
                    <ul>
                        <li><a href="how_it_works.php">How it Works</a></li>
                        <li><a href="contact.html">Contact</a></li>
                        <li><a href="typography.html">About us</a></li>
                    </ul>
                </div>
                <div class="col-md-3 footer-grid">
                    <h4 class="footer-head">Information</h4>
                    <ul>
                        <li><a href="regions.html">Locations Map</a></li>
                        <li><a href="terms.html">Terms of Use</a></li>
                        <li><a href="popular-search.html">Popular searches</a></li>
                        <li><a href="privacy.html">Privacy Policy</a></li>
                    </ul>
                </div>
                <div class="col-md-3 footer-grid">
                    <h4 class="footer-head">Contact Us</h4>
                    <span class="hq">Our Office</span>
                    <address>
                        <ul class="location">
                            <li><span class="glyphicon glyphicon-map-marker"></span></li>
                            <li>Biratnagar,Morang</li>
                            <div class="clearfix"></div>
                        </ul>
                        <ul class="location">
                            <li><span class="glyphicon glyphicon-earphone"></span></li>
                            <li>+977 9842553420</li>
                            <div class="clearfix"></div>
                        </ul>
                        <ul class="location">
                            <li><span class="glyphicon glyphicon-envelope"></span></li>
                            <li><a href="mailto:info@example.com">info@rishavtakuri.com.np</a></li>
                            <div class="clearfix"></div>
                        </ul>
                    </address>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
    <div class="footer-bottom text-center">
        <div class="container">
            <div class="footer-logo">
                <a href="index.html"><span>ads</span>nagar</a>
            </div>
            <div class="footer-social-icons">
                <ul>
                    <li><a class="facebook" href="http://facebook.com/adsnagar"><span>Facebook</span></a></li>
                    <li><a class="twitter" href="http://twitter.com"><span>Twitter</span></a></li>
                    <li><a class="googleplus" href="http://google.com"><span>Google+</span></a></li>

                </ul>
            </div>
            <div class="copyrights">
                <p> © 2018 adsnagar. All Rights Reserved | Design by  <a href="http://adsnagar.com"> adsnagar</a></p>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</footer>
<!--footer section end-->



<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-select.js"></script>

</body>

</html>
