<?php




class Config{


    const SMTP_HOST ='smtp.mailtrap.io';
    const SMTP_PORT = 25;
    const SMTP_USER ='1067e88453ae01';
    const SMTP_PASSWORD = '7f8da05fe5b804';

}


?>